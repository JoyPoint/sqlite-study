This directory contains all SQLite3 version 3.6.18 files needed on Windows platforms.

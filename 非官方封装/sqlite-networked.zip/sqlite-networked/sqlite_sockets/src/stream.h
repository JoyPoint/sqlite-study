//---------------------------------------------------------------------------

#ifndef streamH
#define streamH
//---------------------------------------------------------------------------

#include "object.h"

enum {
	STREAM_BUFFER_STEP = 32
};
class SktStream : public TObject
{
  protected:
   char* base;
   void initBuffer();
   int   size;
   char* pos;

  public:
   SktStream();
   ~SktStream();
   // currently used length
   int length();
   int bufferSize();
   void setPosition(int position);
   int  getPosition();
   void  copyStream(SktStream* stream);
   void  checkresize(int len);
   void  reset();
   void  writeInt(int a);
   int   readInt();
   void  writeByte(unsigned char b);
   unsigned char readByte();
   void  writeStr(char* str);
   char* readStr();

   char** readStrArray(int *len);
   void   writeStrArray(char** strArray, int len);

   int sendBuffer(int socket);
   int recvBuffer(int socket, int maxlen);
};


#endif

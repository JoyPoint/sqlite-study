 /*
   +---------------------------------------------------------+
   | EzSocket library - version 0.0.1                        |
   | (C) 2001, Locrian <locrian@impetus.gr>                  |
   +---------------------------------------------------------+

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef	_LIBEZSOCKET
#define	_LIBEZSOCKET

#include <stdio.h>
#ifdef unix
	#include <stdlib.h>
	#include <unistd.h>
	#include <errno.h>
	#include <string.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <sys/wait.h>
	#include <netdb.h>
	#define SOCKET	int
#else
	#include <windows.h>
#endif

#define EZSOCKET_VER	"0.0.1"

/****** STREAM SOCKET FUNCTIONS *************************/
#define SERVER	1
#define	CLIENT	2
int ezsocket_init(void);
void ezsocket_exit(void);
SOCKET ezsocket(struct sockaddr_in *addr, char *URL, int PORT, int mode);
void ezclose_socket(SOCKET s);
/********* END OF STREAM SOCKET FUNCTIONS ********/



/********* TIME FUNCTIONS ********/
char *ezdate(const char *format);

/* 
	format variable can be:
	A = Date name
	B = Month name
	d = Day of the month (01-31)
	H = Hour(24) (00-23)
	I = Hour(12) (01-12)
	M = Minuets (00-59)
	m = Month (01-12)
	p = "AM" or "PM"
	S = Seconds (00-61)
	Y = Year (4 digits) (e.x. 2001)
	y = Year (2 digits) (e.x. 01)
	Z = TimeZone
	Example: "%d/%m/%Y - %H:%M:%S\n"

*/
/********* END OF TIME FUNCTIONS ********/
#endif

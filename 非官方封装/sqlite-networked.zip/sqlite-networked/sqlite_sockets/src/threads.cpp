//---------------------------------------------------------------------------

#include "threads.h"

//---------------------------------------------------------------------------

#ifdef   _WIN32

void
sleep_ms (unsigned int ms)
{
  Sleep (ms);
}

DWORD WINAPI
executeThread (LPVOID param)
{
  TThread *thread = (TThread *) param;
  thread->execute ();
  delete thread;
  return 0;
}



TThread::TThread (const char *name):TAbstractThread (name)
{
  handle = 0;
}

void
TThread::start ()
{
  int flags = 0;
  DWORD id = 1;
  //if (createSuspended) flags += CREATE_SUSPENDED;
  this->handle = CreateThread (NULL, 0, executeThread, this, flags, &id);
}

TThread::~TThread ()
{
  CloseHandle (handle);
}


void
TThread::setPriority (TPriority priority)
{
  int winpr = THREAD_PRIORITY_NORMAL;
  switch (priority)
    {
    case prIdle:
      winpr = THREAD_PRIORITY_IDLE;
      break;
    case prLower:
      winpr = THREAD_PRIORITY_BELOW_NORMAL;
      break;
    case prHigher:
      winpr = THREAD_PRIORITY_ABOVE_NORMAL;
      break;
    case prHighest:
      winpr = THREAD_PRIORITY_HIGHEST;
      break;
    }

  if (!SetThreadPriority (handle, winpr))
    {
      warn ("priority setting failed");
    }
}


//------------------ TWaitCondition (Windows implementation) -------------------
// solution by http://www.cs.wustl.edu/~schmidt/win32-cv-1.html

/*
int 
pthread_cond_init (pthread_cond_t *cv,
                   const void * dummy)
{
  cv->waiters_count_ = 0;
  cv->was_broadcast_ = 0;
  cv->sema_ = CreateSemaphore (NULL,       // no security
                                0,          // initially 0
                                0x7fffffff, // max count
                                NULL);      // unnamed 
  InitializeCriticalSection (&cv->waiters_count_lock_);
  cv->waiters_done_ = CreateEvent (NULL,  // no security
                                   FALSE, // auto-reset
                                   FALSE, // non-signaled initially
                                   NULL); // unnamed
}

int
pthread_cond_wait (pthread_cond_t *cv, 
                   pthread_mutex_t *external_mutex)
{
  // Avoid race conditions.
  EnterCriticalSection (&cv->waiters_count_lock_);
  cv->waiters_count_++;
  LeaveCriticalSection (&cv->waiters_count_lock_);

  // This call atomically releases the mutex and waits on the
  // semaphore until <pthread_cond_signal> or <pthread_cond_broadcast>
  // are called by another thread.
  SignalObjectAndWait (*external_mutex, cv->sema_, INFINITE, FALSE);

  // Reacquire lock to avoid race conditions.
  EnterCriticalSection (&cv->waiters_count_lock_);

  // We're no longer waiting...
  cv->waiters_count_--;

  // Check to see if we're the last waiter after <pthread_cond_broadcast>.
  int last_waiter = cv->was_broadcast_ && cv->waiters_count_ == 0;

  LeaveCriticalSection (&cv->waiters_count_lock_);

  // If we're the last waiter thread during this particular broadcast
  // then let all the other threads proceed.
  if (last_waiter)
    // This call atomically signals the <waiters_done_> event and waits until
    // it can acquire the <external_mutex>.  This is required to ensure fairness. 
    SignalObjectAndWait (cv->waiters_done_, *external_mutex, INFINITE, FALSE);
  else
    // Always regain the external mutex since that's the guarantee we
    // give to our callers. 
    WaitForSingleObject (*external_mutex, INFINITE);
}

int
pthread_cond_signal (pthread_cond_t *cv)
{
  EnterCriticalSection (&cv->waiters_count_lock_);
  int have_waiters = cv->waiters_count_ > 0;
  LeaveCriticalSection (&cv->waiters_count_lock_);

  // If there aren't any waiters, then this is a no-op.  
  if (have_waiters)
    ReleaseSemaphore (cv->sema_, 1, 0);
}

int
pthread_cond_broadcast (pthread_cond_t *cv)
{
  // This is needed to ensure that <waiters_count_> and <was_broadcast_> are
  // consistent relative to each other.
  EnterCriticalSection (&cv->waiters_count_lock_);
  int have_waiters = 0;

  if (cv->waiters_count_ > 0) {
    // We are broadcasting, even if there is just one waiter...
    // Record that we are broadcasting, which helps optimize
    // <pthread_cond_wait> for the non-broadcast case.
    cv->was_broadcast_ = 1;
    have_waiters = 1;
  }

  if (have_waiters) {
    // Wake up all the waiters atomically.
    ReleaseSemaphore (cv->sema_, cv->waiters_count_, 0);

    LeaveCriticalSection (&cv->waiters_count_lock_);

    // Wait for all the awakened threads to acquire the counting
    // semaphore.
    WaitForSingleObject (cv->waiters_done_, INFINITE);
    // This assignment is okay, even without the <waiters_count_lock_> held
    // because no other waiter threads can wake up to access it.
    cv->was_broadcast_ = 0;
  }
  else
    LeaveCriticalSection (&cv->waiters_count_lock_);
}


//-------------------------------------------------
//                WaitCondition (Pthread implementation)
//-------------------------------------------------

TWaitCondition::TWaitCondition (const char *name):
TAbstractWaitCondition (name)
{

  mutex = CreateMutex (NULL, BOOL (0), NULL);
  int ret = pthread_cond_init (&cond, NULL);

  if (ret)
    {
      err ("pthread_cond_init returned an error status");
    }

  //out("created");
}

TWaitCondition::~TWaitCondition ()
{
  debug ("waitCondition destructor");

  CloseHandle(mutex);
  CloseHandle(cond.sema_);
  CloseHandle(cond.waiters_done_);
  debug ("destroyed");
}

bool
TWaitCondition::wait ()
{
  WaitForSingleObject(mutex, INFINITE);
  int ret = pthread_cond_wait (&cond, &mutex);
  ReleaseMutex(mutex);
  return ret == 0;
}


void
TWaitCondition::wakeAll ()
{
  pthread_cond_broadcast (&cond);
}
*/

//------------------------ TMutex (win32) -------------------------
TMutex::TMutex (const char *name):
TAbstractMutex (name)
{
  handle = CreateMutex (NULL, BOOL (0), NULL);
}

TMutex::~TMutex ()
{
  CloseHandle (handle);
}

void
TMutex::unlock ()
{
  ReleaseMutex (handle);
}

void
TMutex::lock ()
{
  WaitForSingleObject (handle, INFINITE);

}

#endif


// Linux style with pthreads

#ifndef _WIN32

void
sleep_ms (unsigned int ms)
{
  usleep (ms * 1000);
}


void *
theThread (void *param)
{
  TThread *thread = (TThread *) param;
  int resd = pthread_detach(pthread_self());
   if (resd !=0) perror("pthread_detach failed");
   else printf("thread detach OK\n");
  thread->execute ();
  delete thread;
  return 0;
}


TThread::TThread (const char *name):TAbstractThread (name)
{
}

TThread::~TThread ()
{
  debug ("canceling thread");
// dont cancel thread,
//  pthread_cancel(this->thread);
}

void
TThread::start ()
{
  t_id = pthread_create (&thread, NULL, theThread, this);
  if (t_id == 0) 
    {
      //int resd = pthread_detach(thread);
      //if (resd !=0) perror("pthread_detach failed"); 
      //else printf("thread detach OK\n");
    }
  else
  if (t_id == EAGAIN) printf("pthread_create failed with error EAGAIN\n");
  else
  if  (t_id == EFAULT) printf("pthread_create failed with error EFAULT\n");
  else
  if  (t_id == EINVAL) printf("pthread_create failed with error EINVAL\n");
  else    printf("pthread_create failed with error %d\n",t_id);
    
}


void
TThread::setPriority (TPriority priority)
{
  warn ("setPriority() not supported with pthreads");
}

//-------------------------------------------------
//                WaitCondition (Pthread implementation)
//-------------------------------------------------

/*
TWaitCondition::TWaitCondition (const char *name):
TAbstractWaitCondition (name)
{

  pthread_mutex_init (&mutex, 0);
  int ret = pthread_cond_init (&cond, NULL);

  if (ret)
    {
      err ("pthread_cond_init returned an error status");
    }

  //out("created");
}

TWaitCondition::~TWaitCondition ()
{
  debug ("waitCondition destructor");

  pthread_mutex_destroy (&mutex);
  int ret = pthread_cond_destroy (&cond);
  if (ret)
    {
      out
	("pthread_cond_destroy returned an error status, maybe we have threads sleeping on us");
      //  pthread_cond_broadcast(&cond);
    }

  debug ("destroyed");
}

bool
TWaitCondition::wait ()
{
  pthread_mutex_lock (&mutex);
  int ret = pthread_cond_wait (&cond, &mutex);
  pthread_mutex_unlock (&mutex);
  return ret == 0;
}


void
TWaitCondition::wakeAll ()
{
  pthread_cond_broadcast (&cond);
}

*/
//----------------------- TMutex --------------------------

TMutex::TMutex (const char *name):
TAbstractMutex (name)
{
  pthread_mutex_init (&mutex, 0);
}

TMutex::~TMutex ()
{
  pthread_mutex_destroy (&mutex);
}

void
TMutex::unlock ()
{
  pthread_mutex_unlock (&mutex);
}

void
TMutex::lock ()
{
  pthread_mutex_lock (&mutex);
}


#endif



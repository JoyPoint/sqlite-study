//---------------------------------------------------------------------------

#ifndef stackH
#define stackH
//---------------------------------------------------------------------------

#if _WIN32
#include <windows.h>
#endif

#include "stream.h"

typedef unsigned char STACK_Byte;

typedef char* STACK_Str;

typedef struct
          {
            int len;
            STACK_Str* items;
          } STACK_StrArray;

typedef int STACK_Int;

enum {

   STACK_OK = 0,
   STACK_SEND_ERROR = 1,
   STACK_RECV_HEADER_ERROR = 2,
   STACK_RECV_BODY_ERROR = 3,
   STACK_ACCEPT_ERROR = 4,
   STACK_CONNECT_ERROR = 5,
   STACK_WRONG_FORMAT_OR_TOO_BIG = 6,
   STACK_SERVER_STUB_ERROR = 7,
   STACK_RECV_NODATA = 8,		// received no data, probably closed connection
   STACK_USER_ERROR_BASE = 1000,
   STACK_MAX_SIZE = 1024*1024*10	 // 10MB
};

class SktStack : public SktStream
{
private:
   int toGet;
   int HEADER_SIZE;
protected:
   int sockfd;
   void *sock_addr;
   int sock_addr_length;
   SktStream* header;
public:


   static const char* errorMessage(int err);
   
   int invoke(int sock);

   int socket() { return sockfd; }
   void insertHeader();
   int sendMessageBuffer(int sock);
   void readHeader();
   int recvMessage(int sock);
   int sendMessage(int sock);

   STACK_StrArray readStrArray();
   void writeStrArray(const STACK_StrArray& strArray);

   SktStack();
   ~SktStack();
};

#endif

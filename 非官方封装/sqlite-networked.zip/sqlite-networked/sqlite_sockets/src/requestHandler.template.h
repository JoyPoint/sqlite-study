�file requestHandler.h
//---------------------------------------------------------------------------

#ifndef requestHandlerH
#define requestHandlerH
//---------------------------------------------------------------------------

#include "stack.h"
#include <list.h>


static const int BAD_HANDLE = 1;

//! holds a pointer and associated handle
class PointerHolder
{
protected:
   int h;
   void* p;
public:
   int getHandle()
   {
      return h;
   }
   void* getPointer()
   {
      return p;
   }
   PointerHolder(void* pointer, int handle):h(handle),p(pointer)
   {
   }
};

//! handles client requests. All remote methods are implemented here.
//! this class is automatically generated from template
class RequestHandler
{

protected:
int handlecounter;

list<PointerHolder*> dbhandles;

list<PointerHolder*> vmhandles;

PointerHolder* getHolderByHandle(list<PointerHolder*> &v, int handle);

// remote methods goes here
�cd methods
�foreach

//! server implementation for method �NAME
int svc_�NAME(
                �var2=
                �cd in
                �var2=,
                �foreach
                  STACK_�PARAM[0] in_�NAME �SEP
                �end
                �cd ..
                �cd out
                 �VAR2
                �foreach
                  STACK_�PARAM[0] *out_�NAME �SEP
                �end
                �cd ..
             );
�end
�cd ..
public:
 //! constuctor
 RequestHandler();

 //! destructor
 ~RequestHandler();

 //! reads request data from stack and calls the individual method
 int handleRequest(int new_socket, SktStack *stack);
};

#endif

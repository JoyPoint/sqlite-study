#ifndef objectH
#define objectH
//---------------------------------------------------------------------------


#include <iostream>
#include <stdio.h>


#ifndef NULL
#define NULL 0
#endif

class TObject;

/**
 * TObject is the base class of all objects in agl.
 * all instances are stored in a list and
 * deleted automaticaly upon exiting
 */
class TObject
{
private:
  TObject * _next;
  /**
   * Stores the object's name.
   */
  const char *name;
protected:
    friend void _deleteAllObjects ();
  friend void _removeFromList (TObject * obj);
public:
  /**
   * Creates a new object with a name.
   */
    TObject (const char *objname = 0);
    virtual ~ TObject ();
	/**
   * Returns the name of the class.
   */
  const char *className () const;
  /**
   * Sets the name of the object.
   */
  void setName (const char *name);
  /**
   * Returns the name of the object.
   */
  const char *getName () const;
  /**
   * status output.
   */
  void out (const char *s);

  /**
  *  debug output
  */
  void debug (const char *s);

  /**
   * Error output.
   */
  void err (const char *s);
  /**
   * Warning output.
   */
  void warn (const char *s);
};


/* void out(TObject *obj,char* s); */



#endif



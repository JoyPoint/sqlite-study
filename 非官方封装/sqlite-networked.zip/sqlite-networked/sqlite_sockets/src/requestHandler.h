//---------------------------------------------------------------------------

#ifndef requestHandlerH
#define requestHandlerH
//---------------------------------------------------------------------------

#include "stack.h"
#include <list.h>


static const int BAD_HANDLE = 1;

//! holds a pointer and associated handle
class PointerHolder
{
protected:
   int h;
   void* p;
public:
   int getHandle()
   {
      return h;
   }
   void* getPointer()
   {
      return p;
   }
   PointerHolder(void* pointer, int handle):h(handle),p(pointer)
   {
   }
};

//! handles client requests. All remote methods are implemented here.
//! this class is automatically generated from template
class RequestHandler
{

protected:
int handlecounter;

list<PointerHolder*> dbhandles;

list<PointerHolder*> vmhandles;

PointerHolder* getHolderByHandle(list<PointerHolder*> &v, int handle);

// remote methods goes here

//! server implementation for method sqlite_open
int svc_sqlite_open(
                  STACK_Str in_filename ,
                  STACK_Int *out_errcode ,
                  STACK_Str *out_errmsg ,
                  STACK_Int *out_db_handle 
             );

//! server implementation for method sqlite_close
int svc_sqlite_close(
                  STACK_Int in_db_handle ,
				  STACK_Int *out_err
             );

//! server implementation for method sqlite_compile
int svc_sqlite_compile(
                  STACK_Int in_db_handle ,
                  STACK_Str in_sql 
                 ,
                  STACK_Int *out_tailIndex ,
                  STACK_Int *out_vm_handle ,
                  STACK_Int *out_errcode ,
                  STACK_Str *out_errmsg 
             );

//! server implementation for method sqlite_step
int svc_sqlite_step_server(
                  STACK_Int in_vm_handle ,
				  STACK_Int	*out_nvalues ,
				  STACK_Int *out_errcode,
				  void **vm);


//! server implementation for method sqlite_finalize
int svc_sqlite_finalize(
                  STACK_Int in_vm_handle ,
                  STACK_Int *out_errcode ,
                  STACK_Str *out_errmsg 
             );

//! server implementation for method sqlite_reset
int svc_sqlite_reset(
                  STACK_Int in_vm_handle 
                 ,
                  STACK_Int *out_errcode ,
                  STACK_Str *out_errmsg 
             );

//! server implementation for method sqlite_changes
int svc_sqlite_changes(
                  STACK_Int in_db_handle 
                 ,
                  STACK_Int *out_count 
             );

//! server implementation for method sqlite_last_insert_rowid
int svc_sqlite_last_insert_rowid(
                  STACK_Int in_db_handle 
                 ,
                  STACK_Int *out_rowid 
             );

//! server implementation for method sqlite_interrupt
int svc_sqlite_interrupt(
                  STACK_Int in_db_handle 
             );

//! server implementation for method sqlite_libversion
int svc_sqlite_libversion(
                 
                  STACK_Str *out_version 
             );

//! server implementation for method sqlite_libencoding
//int svc_sqlite_libencoding(
//                 
//                  STACK_Str *out_encoding 
//             );

//! server implementation for method sqlite_open

// extensions
int svc_sqlite_errmsg(STACK_Int in_db_handle, STACK_Str *out_msg);

#ifdef ANDROMEDA
int svc_sqlite_db_exists(
                  STACK_Str in_filename ,
                  STACK_Int *out_errcode 
				  );
#endif

public:
 //! constuctor
 RequestHandler();

 //! destructor
 ~RequestHandler();

 //! reads request data from stack and calls the individual method
 int handleRequest(int new_socket, SktStack *stack);
};

#endif

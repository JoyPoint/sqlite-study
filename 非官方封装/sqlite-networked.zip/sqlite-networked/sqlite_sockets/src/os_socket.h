//---------------------------------------------------------------------------

#ifndef os_socketH
#define os_socketH
//---------------------------------------------------------------------------
#include <stdio.h>
#ifdef _WIN32
#include <windows.h>
//#include <winsock2.h>
#else
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
typedef int SOCKET;
#endif

int os_socket_init();

int os_socket_deinit();


SOCKET os_socket_accept(SOCKET sockfd,struct sockaddr * sock_addr, int * sock_addr_length);

SOCKET os_socket_server(int port);

SOCKET os_socket_client(int port, char* hosturl, struct sockaddr_in *addr);

void os_socket_close(SOCKET sock);

#endif


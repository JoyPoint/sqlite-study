//---------------------------------------------------------------------------

#include "object.h"
#include <stdlib.h>
#include <typeinfo>
#include <string>

using
  std::cout;
using
  std::endl;

// uncomment this for more debug information
// or comment out for less debug information
//#define NDEBUG

int
  count =
  0;

TObject *
  _ObjectsChain =
  0;

bool
  deleting =
  false;

void
_deleteAllObjects ()
{
  deleting = true;
  TObject *
    temp;
  while (_ObjectsChain)
    {
      temp = _ObjectsChain;
      _ObjectsChain = temp->_next;
      delete
	temp;
    }
  deleting = false;
}


class
  DummyForClose
{
  public:~
  DummyForClose ()
  {
    // _deleteAllObjects ();
  }
};

DummyForClose
  dummy;


void
_removeFromList (TObject * obj)
{
  if (!_ObjectsChain)
    return;
  if (_ObjectsChain == obj)
    {
      _ObjectsChain = _ObjectsChain->_next;
      return;
    }
  TObject *
    iter =
    _ObjectsChain;
  while (iter)
    {
      if (iter->_next == obj)
	{
	  iter->_next = iter->_next->_next;
	  return;
	}
      iter = iter->_next;
    }
}

//--------------------- TObject --------------------
TObject::TObject (const char *objname)
{
  if (objname)
    name = strdup (objname);
  else
    name = strdup ("<unnamed>");

#ifdef _DEBUG
  cout << count << " created\n";
#endif
  count++;
  this->_next = _ObjectsChain;
  _ObjectsChain = this;
}

TObject::~TObject ()
{
  count--;
  if (!deleting)
    {
      _removeFromList (this);
     // out ("You don't have to free subclasses of TObject !!!\n They will be deleted automatically\n");
    }

  if (!count)
    {
      cout << "ANTVIS LIBRARY: All Objects were cleanly deleted." << endl;
    }
  else if (count < 0)
    {
      warn ("are you trying to destroy one instance more than once?");
    }

  if (name)
    {
      free ((char *) name);
      name = 0;
    }

#ifdef _DEBUG
  cout << count << " destroyed\n";
#endif
}


void
TObject::out (const char *s)
{
#ifdef NDEBUG
  if (name)
    {
      cout << className () << "(" << name << "): " << s << endl;
    }
  else
    {
      cout << className () << ": " << s << endl;
    }
#endif
}

void
TObject::debug (const char *s)
{
#ifdef NDEBUG
  if (name)
    {
      cout << className () << "(" << name << "): " << s << endl;
    }
  else
    {
      cout << className () << ": " << s << endl;
    }
#endif
}

void
TObject::err (const char *s)
{
  // will be printed anyway
  cout << "ERROR : ";
  if (name)
    {
      cout << className () << "(" << name << "): " << s << endl;
    }
  else
    {

      cout << className () << ": " << s << endl;
    }
}

void
TObject::warn (const char *s)
{
  // will be printed anyway
  cout << "WARNING : ";
  if (name)
    {
      cout << className () << "(" << name << "): " << s << endl;
    }
  else
    {
      cout << className () << ": " << s << endl;
    }
}


void
TObject::setName (const char *objname)
{
  if (name)
    {
      free ((char *) name);
    }
  name = objname ? strdup (objname) : strdup ("<unnamed>");
}

const char *
TObject::getName () const
{
  return name;
}

const char *
TObject::className () const
{
  char *p = "SomeObject";//(char *) typeid (*this).name ();

  // under Linux there are numbers before the class name
  // so we cut them away here
  while ((*p >= '0') && (*p <= '9'))
    {
      p++;
    }
  return p;
}

#undef NDEBUG

//---------------------------------------------------------------------------

#pragma hdrstop
  
#include <stdio.h>
#include "sqlite3.h"
#include <stdlib.h>
  

//---------------------------------------------------------------------------
  
/*
** The type for a callback function.
*/
//typedef int (*sqlite_callback)(void*,int,char**, char**);
  
//#pragma argsused
  
bool error (char *errmsg) 
{
  
if (errmsg != 0)
    
    {
      
	printf ("ERROR: %s\n", errmsg);
      
	sqlite3_free(errmsg);
      
	return true;
    
	}
  
	else
    
	return false;

}


int
callback (void *param, int cols, char **values, char **colnames) 
{
  
printf ("|");
  
for (int c = 0; c < cols; c++)
    
    {
      
printf ("%s|", values[c]);
    
} 
printf ("\n");
  
return 0;

}

#include <string.h>

void
test (char *url, char *sql) 
{
  char *errmsg;
#ifdef ANDROMEDA
  printf("db test..\n");
  int exists = sqlite3_DB_Exists(url);
  printf("db %s : %d\n",url,exists);
#endif
  printf("db open...\n");
  sqlite3 *db=NULL;
  int err = sqlite3_open (url, &db);

  {
  const char * errm = sqlite3_errmsg(db);
  printf("Err : %s\n",errm);
  }

  if (err!=SQLITE_OK) 
    {
      printf("res=%d\n",0);
      //error (errmsg);
      return;
    }
  printf("db opened\n");
  
if (sql != 0)
     {
      int res = sqlite3_exec (db, sql, callback, 0, &errmsg);
      printf("result of exec %d\n",res);
      //error (errmsg);
    
}
  
sqlite3_close (db);
}

int main (int argc, char *argv[]) 
{
  
if (argc != 3)
    
    {
      
printf ("Usage: %s <URL> <SQL>\n", argv[0]);
      
printf ("URL -> user:passwort@host:port/database\n");
      
printf ("SQL -> SQL Statement\n");
    
}
  
  else
    
    {
      
	test (argv[1], argv[2]);
    
	}

	return(0);
}


//---------------------------------------------------------------------------

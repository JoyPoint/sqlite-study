//---------------------------------------------------------------------------

#pragma hdrstop

#include "stack.h"
#include "os_socket.h"

//---------------------------------------------------------------------------
//#pragma package(smart_init)


SktStack::SktStack ()
  : SktStream()
{
  HEADER_SIZE = 4;
  header = new SktStream();
}

SktStack::~SktStack()
{
  delete header;
}

const char* SktStack::errorMessage(int err)
{
  switch (err)
  {
    case STACK_OK: return "No Error";
    case STACK_SEND_ERROR: return "Stack send error";
	case STACK_RECV_NODATA: return "Stack received no data";
    case STACK_RECV_HEADER_ERROR : return "Stack receive header error";
    case STACK_RECV_BODY_ERROR: return "Stack receive body error";
    case STACK_ACCEPT_ERROR : return "Stack accept error";
    case STACK_CONNECT_ERROR : return "Stack connect error";
    case STACK_WRONG_FORMAT_OR_TOO_BIG: return "Stack wrong format or too big message";
    case STACK_SERVER_STUB_ERROR : return "Stack server stub error";
  }

  if (err > STACK_USER_ERROR_BASE) return "Stack user error";
  return  "Unknown stack error";
}

void SktStack::insertHeader()
{
 header->reset();
 int body_length = length();
 header->writeInt(body_length);
 header->copyStream(this);
 reset();
 copyStream(header);
}


void SktStack::readHeader()
{
   toGet = readInt();
}


int SktStack::invoke(int sock)
{
    int sent_res = sendMessage(sock);
    
    if (sent_res == STACK_OK) return recvMessage(sock);
    else 
    {
      printf("invoke failed with %d\n",sent_res);
      return sent_res;
    }
}


int SktStack::sendMessageBuffer(int sock)
{
   int sent = sendBuffer(sock);
   if (sent != length())
   {
      //fprintf(stdout,"Couldn't send message \n");
      return STACK_SEND_ERROR;
   }
   else
   {
      return STACK_OK;
   }
}

int SktStack::sendMessage(int sock)
{
   insertHeader();
   return sendMessageBuffer(sock);
}


int SktStack::recvMessage(int sock)
{
    reset();
    int received = recvBuffer(sock,HEADER_SIZE);
    if (received != HEADER_SIZE)
    {
		if(received<=0) { return(STACK_RECV_NODATA); }
#ifdef _DEBUG
	  fprintf(stdout,"Couldn't receive header, wanted %d got %d\n",HEADER_SIZE,received);
#endif
      return STACK_RECV_HEADER_ERROR;
    }
    reset();

    readHeader();

    if (toGet > STACK_MAX_SIZE)
    {
      return STACK_WRONG_FORMAT_OR_TOO_BIG;
    }

    checkresize(toGet);
    received =  recvBuffer(sock,toGet);
    toGet -= received;

    if (toGet != 0)
    {
      //fprintf(stdout,"Couldn't receive whole message\n");
      return STACK_RECV_BODY_ERROR;
    }
    reset();

    // skip header
    readHeader();

    return STACK_OK;
}

STACK_StrArray SktStack::readStrArray()
{
  STACK_StrArray res;
  res.items = SktStream::readStrArray(&(res.len));
  return res;
}

void SktStack::writeStrArray(const STACK_StrArray& strArray)
{
   SktStream::writeStrArray(strArray.items,strArray.len);
}


//---------------------------------------------------------------------------

#pragma hdrstop

#include "stream.h"
#include "os_socket.h"

#include <string.h>
#include <assert.h>

#define MAXLEN (16*1024)

//---------------------------------------------------------------------------
//#pragma package(smart_init)


SktStream::SktStream()
{
  initBuffer();
}

SktStream::~SktStream()
{
  delete[] base;
}


void SktStream::reset()
{
  pos = base;
}

int SktStream::bufferSize()
{
   return size;
}


void SktStream::copyStream(SktStream* stream)
{
  int source_len = stream->length();
  checkresize(source_len);
  memcpy(pos,stream->base,source_len);
  pos += source_len;
}

void SktStream::checkresize(int len)
{
   if (size-(pos-base) < len)
   {
    int newsize = size;
    while (newsize-(pos-base) < len) newsize+=STREAM_BUFFER_STEP;
    char* tmp = new char[newsize];
    assert(tmp);
    memcpy(tmp,base,size);
    int p = pos-base;
    pos = tmp+p;
    delete[] base;
    base = tmp;
    size = newsize;
   }
}

void SktStream::writeByte(unsigned char b)
{
  checkresize(1);
  *pos = b;
  pos++;
}

void SktStream::writeInt(int a)
{
  checkresize(sizeof(int));
  *((int*)pos) = a;
  pos+=sizeof(int);
}


void SktStream::setPosition(int position)
{
   pos = base+position;
}

int SktStream::getPosition()
{
  return (pos-base);
}

int SktStream::length()
{
  return (pos-base);
}

void  SktStream::writeStr(char* str)
{
  if (str == 0)
  {
     writeByte(0);
     return;
  }
  int len = strlen(str);
  if (len<=253)
  {
    writeByte(len+1);
  }
  else
  {
    writeByte(255);
    writeInt(len+1);
  }

  checkresize(len+1);
  memcpy(pos,str,len);
  pos+=(len);
  writeByte(0);
}

char* SktStream::readStr()
{
  unsigned char len = readByte();
  int reallen;
  if (len == 0) return 0;
  if ((unsigned char)len == (unsigned char)255) reallen=readInt();
  else reallen = (unsigned char)len;
  assert(pos < base+size);
  char* res = pos;
  pos+=reallen;
  return res;
}

unsigned char SktStream::readByte()
{
  assert(pos < base+size);
  unsigned char c = *pos;
  pos++;
  return c;
}

int SktStream::readInt()
{
  assert(pos < base+size);
  int res = *((int*)pos);
  pos+=sizeof(int);
  return res;
}

char** SktStream::readStrArray(int *len)
{
  int l = readInt();
  char **ppchar = new char*[l];
  for(int i=0;i<l;i++)
  {
     ppchar[i] = readStr();
  }
  (*len) = l;
  return ppchar;
}

void   SktStream::writeStrArray(char **strArray, int len)
{
   writeInt(len);
   for(int i=0;i<len;i++)
   {
     writeStr(strArray[i]);
   }
}


void SktStream::initBuffer()
{
  base = new char[STREAM_BUFFER_STEP];
  assert(base);
  pos  = base;
  size = STREAM_BUFFER_STEP;
}

// partition the buffer in chunks of MAXLEN or less
int SktStream::sendBuffer(int socket)
{ long len = pos-base;
  long off = 0;
  while(off<len)
  {	int thislen = min(len-off,MAXLEN);
	int sent = send(socket,base+off,thislen,0);
	if(sent==SOCKET_ERROR) { return(len); }
	off +=sent;
  }
  return(off);
}

// receive a buffer, possibly in multiple chunks
int SktStream::recvBuffer(int socket, int maxlen)
{
  checkresize(maxlen);
  int received = 0;
  while(received<maxlen)
  {	int rnow = recv(socket,pos+received,maxlen-received,0);
  if(rnow>0) { received+=rnow; } else { break; }
  }
  return received;
}



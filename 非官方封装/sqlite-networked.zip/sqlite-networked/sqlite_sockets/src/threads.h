//---------------------------------------------------------------------------

#ifndef threadsH
#define threadsH
//---------------------------------------------------------------------------

/**
* platform dependent implementation of thread, mutex and condition
* separated by defines. Windows style works with Borland c++ builder.
*/


#include "object.h"

// force current thread to sleep for ms milliseconds
void sleep_ms (unsigned int ms);

enum TPriority
{ prIdle, prLower, prNormal, prHigher, prHighest };

/**
 * Defines the requirements for classes implementing a thread.
 */
class TAbstractThread:public TObject
{
private:

protected:

public:
  /**
   * Creates a new thread giving it a name.
   */
  TAbstractThread (const char *name = 0):TObject (name)
  {
  }

  virtual ~ TAbstractThread ()
  {
  };

  /**
   * This method is pure virtual, and must be implemented in derived classes
   * in order to do useful work. Returning from this method will end the
   * execution of the thread.
   */
  virtual void execute () = 0;
  /**
   * This begins the execution of the thread by calling execute(), which
   * should be reimplemented in a concrete TThread subclass to contain your
   * code.
   */
  virtual void start () = 0;
  /**
   * Sets the priority of the thread to TPriority.
   */
  virtual void setPriority (TPriority priority) = 0;
};

/**
 * Defines the requirements for wait condition classes.
 */
class TAbstractWaitCondition:public TObject
{
public:
  TAbstractWaitCondition (const char *name = 0):TObject (name)
  {
  }
  virtual ~ TAbstractWaitCondition ()
  {
  }
  /**
   * The thread calling this will block until either of these conditions is
   * met: 
   * wakeOne() or wakeAll() has been called by another thread.
   */
  virtual bool wait () = 0;

  /**
   * This wakes all threads waiting on the TWaitCondition. The order in which
   * the threads are woken up depends on the operating system's scheduling
   * policies, and cannot be controlled or predicted. */
  virtual void wakeAll () = 0;
};

class TAbstractMutex:public TObject
{
public:
  TAbstractMutex (const char *name = 0):TObject (name)
  {
  }
  virtual void lock () = 0;
  virtual void unlock () = 0;
};



//
//-------------------------------------------------
//                WINDOWS STYLE WITH WIN32
//-------------------------------------------------


#ifdef _WIN32
#include <windows.h>
#include <basetsd.h>
#include <winbase.h>
/*
typedef struct
{
  int waiters_count_;
  // Number of waiting threads.

  CRITICAL_SECTION waiters_count_lock_;
  // Serialize access to <waiters_count_>.

  HANDLE sema_;
  // Semaphore used to queue up threads waiting for the condition to
  // become signaled. 

  HANDLE waiters_done_;
  // An auto-reset event used by the broadcast/signal thread to wait
  // for all the waiting thread(s) to wake up and be released from the
  // semaphore. 

  size_t was_broadcast_;
  // Keeps track of whether we were broadcasting or signaling.  This
  // allows us to optimize the code if we're just signaling.
} pthread_cond_t;

typedef HANDLE pthread_mutex_t;
*/

/**
 * Thread implementation for Win32 C++ Builder and MSVC plattform.
 */
class TThread:public TAbstractThread
{
protected:
  HANDLE handle;
public:
  TThread (const char *name = 0);
   ~TThread ();
  void start ();
  void setPriority (TPriority priority);
};

/**
 * Implementation of TWaitCondition for Windows (BCB)
 */
/*
class TWaitCondition:public TAbstractWaitCondition
{
private:
  pthread_cond_t cond;
  pthread_mutex_t mutex;
public:
    TWaitCondition (const char *name = 0);
   ~TWaitCondition ();

  bool wait ();
  void wakeAll ();
};
*/

class TMutex:public TAbstractMutex
{
  private:HANDLE handle;
public:
  TMutex (const char *name = 0);
   ~TMutex ();
  virtual void lock ();
  virtual void unlock ();
};

#endif // _BCB

#ifndef  _WIN32
//-------------------------------------------------
//                LINUX STYLE WITH PTHREADS
//-------------------------------------------------

#include <pthread.h>
#include <unistd.h>

/**
 * Thread implementation class for linux wrapping a pthread_t struct.
 */
class TThread:public TAbstractThread
{
protected:
  int t_id;
  pthread_t thread;
public:
    TThread (const char *name = 0);
   ~TThread ();
  void start ();
  void setPriority (TPriority priority);
};

/*
class TWaitCondition:public TAbstractWaitCondition
{
private:
  pthread_cond_t cond;
  pthread_mutex_t mutex;
public:
    TWaitCondition (const char *name = 0);
   ~TWaitCondition ();

  bool wait ();
  void wakeAll ();
};

*/
class TMutex:public TAbstractMutex
{
  private:pthread_mutex_t mutex;
public:
  TMutex (const char *name = 0);
   ~TMutex ();
  virtual void lock ();
  virtual void unlock ();
};

#endif // _BCB

#endif

/**

  Demonstration Sqlite server

  This is a proof-of-concept implementation of a networked sqlite3 server,
  based closely on the sqlite 2.x version at http://www.it77.de/sqlite/sqlite.htm

  While it works, here are some very good reasons why you should not use it
  in any context ouside of your personal sandbox without some very significant
  additional development.

  * the server opens any file you ask it to, and creates it if it doesn't exist.
  * the server talks to anyone who connects to it, and (see above)
  * not tested with any platform but win32
  * no provision for protocol version negotiation, so any deployed programs will
  have no way of knowing if the server they're talking to use really compatible.
  * no special optimization for networking, so latentcy is likely to be a big issue
  * with no awareness of the network, dealing with network-specific problems
  such as lost connectivity or invalid ports is problematic.

  The good things about this proof of concept are these:

  * take any sufficiently simple program that uses sqlite3, link it with the
	sqlite_networked_client library INSTEAD of sqlite3.lib or sqlite3.dll, and
	if it links, it will probably work.  At least enough to show that the approach
	is viable.


  Some other good things to know:

  In effect, every server function has two error return ranges, the native sqlite
  values, and an an extended range of server-specific error returns.  When the
  client revceives an error return from it's stub function, it will have in effect
  THREE possible error return values, from sqlite itself, from the sqlite server,
  and from the client interface.   The first step in debugging unexpected error
  returns is to figure out which entity is generating the error.

  This server package is configured with a limit of 10MB to query and result
  buffers, which limits the largest chunks of data which can be handled.

  */

#if _WIN32
#include <windows.h>
#include <list>				// get standard list implementation
using namespace std;		// needed for msvc
#endif
#include <stdio.h>
#include "stack.h"
#include "requestHandler.h"
#include "threads.h"
#include "os_socket.h"

class ClientConnection : public TObject
{
  public:
  struct sockaddr_in remote_addr;
  int fd_size;
  int new_socket;
  char IP[16];
  SktStack* stack;
  int sockfd;
  ClientConnection(int sockfd):sockfd(sockfd)
  {
    new_socket = 0;
    fd_size = sizeof(struct sockaddr_in);
    stack = new SktStack();
  }

  ~ClientConnection()
  {
     delete stack;
  }

  int accept()
  {
     new_socket = os_socket_accept(sockfd,(sockaddr*)&remote_addr,&fd_size);
     #ifdef _WIN32
      sprintf(IP,"%d.%d.%d.%d",
                 remote_addr.sin_addr.S_un.S_un_b.s_b1,
                 remote_addr.sin_addr.S_un.S_un_b.s_b2,
                 remote_addr.sin_addr.S_un.S_un_b.s_b3,
                 remote_addr.sin_addr.S_un.S_un_b.s_b4);
      IP[15] = 0;
     #else
      IP[0 ] = 0;
     #endif
     return new_socket;
  }
};


class HandlerThread : public TThread
{

  public:
   ClientConnection *connection;

  void execute()
  {
    printf("%s : started\n",getName());
    RequestHandler* myhandler = new RequestHandler(); 
    printf("%s: Client [%s] connected\n",getName(),connection->IP);

    int res = 0;
       while(connection->new_socket)
       {
          res = myhandler->handleRequest(connection->new_socket,connection->stack);
          if (res != STACK_OK)
          {
			if(res!=STACK_RECV_NODATA)
			{
            printf("%s: Request from client [%s] failed with error: %s\n",getName(),connection->IP,SktStack::errorMessage(res));
            if (res == STACK_RECV_HEADER_ERROR) printf("%s: Probably client [%s] dropped the connection\n",getName(),connection->IP);
			}
            os_socket_close(connection->new_socket);
            connection->new_socket = 0;
          }
          else
          {
             // request done with OK.
          }
       }//while connected

    printf("%s: Client [%s] disconnected\n",getName(),connection->IP);

    delete connection;
    delete myhandler;
  }//execute
};

class MainThread : public TThread
{

 public:
 int port;
 bool running;
 void execute()
 {
      SOCKET sockfd = os_socket_server(port);

	if (sockfd == -1)
	  {
	    printf("Couldn't create socket for port %d\n",port);
            return;
	  }
	else
	  {
	    printf("Listening at port %d ...\n",port);
	  }


      ClientConnection* connection;
      HandlerThread*    thread;

      running = true;
      
      while (running)
      {
        connection = new ClientConnection(sockfd);
        connection->setName("Client Connection");
        if (connection->accept() != 0)
        {
          printf("creating thread...\n");
          thread = new HandlerThread();
          thread->setName("Client thread");
          thread->connection = connection;
          // thread will delete connection
          thread->start();
        }
        else
        {
           delete connection;
        }
      }

  }
};


int main(int argc, char** argv)
{
  printf("SQLite Server (prototype) Version 0.31\n");

  if (argc != 2)
  {
      printf("Usage : %s <Port>\n",argv[0]);
  }
  else
  {
      int port;
      sscanf(argv[1],"%d",&port);
      
      os_socket_init();
      
      MainThread *main_thread = new MainThread();
      main_thread->setName("Main Thread");
      main_thread->port = port;
      main_thread->start();

      printf("Press ""Q"" for quit\n");
      int c = getchar();
      while ((c!='q') && (c!='Q'))
      {
        c = getchar();
      }

      os_socket_deinit();
  }
  return 0;
}

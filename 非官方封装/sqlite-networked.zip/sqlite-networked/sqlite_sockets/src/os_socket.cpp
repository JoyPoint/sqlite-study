//---------------------------------------------------------------------------

#pragma hdrstop

#include "os_socket.h"

//---------------------------------------------------------------------------
//#pragma package(smart_init)

int os_socket_init()
{
 int res = 0;
#ifdef _WIN32
	struct WSAData wsaData;
	if ((res = WSAStartup(MAKEWORD(1, 1), &wsaData)) != 0)
        {
		printf("WSAStartup failed.\n");
	}
#endif
 return res;
}

int os_socket_deinit()
{
 int res = 0;
 #ifdef _WIN32
   res = WSACleanup();
 #endif
 return res;
}

SOCKET os_socket_accept(SOCKET sockfd,struct sockaddr * sock_addr, int * sock_addr_length)
{

#ifdef _WIN32
   return  accept(sockfd, (struct sockaddr *)sock_addr,
			               sock_addr_length);
#else
   return accept(sockfd, (struct sockaddr *)sock_addr,
			   (socklen_t*)&sock_addr_length);
#endif
}

SOCKET os_socket_server(int port)
{
  struct sockaddr_in temp;
  struct sockaddr_in *addr = &temp;

  addr->sin_family = PF_INET;
  addr->sin_port = htons(port);
  memset(addr->sin_zero, 0, 8);

  SOCKET sockfd = socket(PF_INET, SOCK_STREAM, 0);

  addr->sin_addr.s_addr = htonl(INADDR_ANY);
  int val = 1;

  if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (const char*)&val, sizeof(val)) == -1)
  {
    perror("setsockopt");
    return(-1);
  }
  if (bind(sockfd, (struct sockaddr *)addr, sizeof(struct sockaddr)) == -1)
  {
    perror("bind");
    return(-1);
  }
  if (listen(sockfd, 5) == -1)
  {
    perror("listen");
    return(-1);
  }
  return sockfd;
}

SOCKET os_socket_client(int port, char* hosturl,  struct sockaddr_in *addr)
{

  addr->sin_family = PF_INET;
  addr->sin_port = htons(port);
  memset(addr->sin_zero, 0, 8);

  SOCKET sockfd = socket(PF_INET, SOCK_STREAM, 0);

  struct hostent *hostaddr;
  if((hostaddr = gethostbyname(hosturl)) == 0) return(-1);
  addr->sin_addr.s_addr = *((unsigned long *)hostaddr->h_addr);

  return sockfd;
}

void os_socket_close(SOCKET sock)
{
   #ifdef _WIN32
    closesocket(sock);
  #else
    close(sock);
  #endif
}

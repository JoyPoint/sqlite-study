//---------------------------------------------------------------------------
//
//        This file contains the client side implementation of the
//        sqlite C++ interface for socket communication
//
//---------------------------------------------------------------------------
//
/**

  Demonstration Sqlite Client

  This is a proof-of-concept implementation of a networked sqlite3 client,
  based closely on the sqlite 2.x version at http://www.it77.de/sqlite/sqlite.htm

  The basic idea is that you build an application using the standard
  sqlite3.h, but using this library instead of sqlite3.lib or sqlite3.dll.

  The functions here are plug-compatible with the corresponding standard
  sqlite3 functions, but communicate with a remore server instead of opening
  a local file.

  While it works, here are some very good reasons why you should not use it
  in any context ouside of your personal sandbox without some very significant
  additional development.

  * no testing on any platform except win32

  * only a subset of the full set of sqlite3 functions are implemented, so
  only very basic sqlite applcations can be linked without modificaion.

  * performance is likely to be poor due to network latentcy

  * it's not convenient to use networked sqlite as an option in
  the same binary - the main sqlite library isn't linked, and if
  it were there would be a huge hazard of accidentally using
  native sqlite functions.

  * error handing for network-related problems, and network-savvy behavior
  in general, is minimal.


  The good things about this proof of concept are these:

  * take any sufficiently simple program that uses sqlite3, link it with the
	sqlite_networked_client library INSTEAD of sqlite3.lib or sqlite3.dll, and
	if it links, it will probably work.  At least enough to show that the approach
	is viable.

  */

#pragma hdrstop


// This include defines the interface of the exported methods.
// Does NOT mean usage of sqlite shared library.(This why "sqlite.h" instead of <sqlite>)
// (This file is part of the client package because client
// lib does not need full sqlite library installed.)
#include "sqlite3.h"

#include "clientStubs.h"
#include <assert.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

//---------------------------------------------------------------------------
//#pragma package(smart_init)

#define CLIENT_ERROR_BASE 1000
#ifdef _DEBUG
#define debug(x) printf(x)
#endif

int libinited = 0;

struct sqlite3
{
  public:
  int handle;
  int flags;
  char errmsg[1024];
};

/*
** Possible values for the sqlite.flags and or Db.flags fields.
**
** On sqlite.flags, the SQLITE_InTrans value means that we have
** executed a BEGIN.  On Db.flags, SQLITE_InTrans means a statement
** transaction is active on that particular database file.
*/
#define SQLITE_VdbeTrace      0x00000001  /* True to trace VDBE execution */
#define SQLITE_Initialized    0x00000002  /* True after initialization */
#define SQLITE_Interrupt      0x00000004  /* Cancel current operation */
#define SQLITE_InTrans        0x00000008  /* True if in a transaction */
#define SQLITE_InternChanges  0x00000010  /* Uncommitted Hash table changes */
#define SQLITE_FullColNames   0x00000020  /* Show full column names on SELECT */
#define SQLITE_ShortColNames  0x00000040  /* Show short columns names */
#define SQLITE_CountRows      0x00000080  /* Count rows changed by INSERT, */
                                          /*   DELETE, or UPDATE and return */
                                          /*   the count using a callback. */
#define SQLITE_NullCallback   0x00000100  /* Invoke the callback once if the */
                                          /*   result set is empty */
#define SQLITE_ReportTypes    0x00000200  /* Include information on datatypes */
                                          /*   in 4th argument of callback */

                                          
void delete_StrArray(STACK_StrArray &sa)
{
    delete[] sa.items;
    sa.len = 0;
}

struct sqlite3_stmt
{

   public:

   int handle;
   STACK_StrArray colValues;
   STACK_StrArray colNames;
   void clear()
   {
     delete_StrArray(colValues);
     delete_StrArray(colNames);
   }

};


void sqliteStrRealloc(char **str)
{
  if (str==0 || *str==0) return;
  char *zNew = strdup(*str);
  free(*str);
  (*str) = zNew;
}

/*
** Free memory previously allocated
*/
void sqliteFree(void *p){
  if( p ){
    free(p);
  }
}

// splits the string into head and tail at the first
// occurance of delim character
int split(char* str, char delim, char** head, char** tail)
{
  int len = strlen(str);
  *head = *tail = NULL;
  for (int i=0;i<len;i++)
  {
    if (str[i] == delim)
    {
      str[i] = 0;
      *head = str;
      *tail = str+i+1;
	  return(TRUE);
    }
  }
  return(FALSE);

}

void parseDatabaseURL( char* URL, char* &dbname)
{ 
  char* userpass = NULL;
  char* serverdb = NULL;

  split(URL,'@',&userpass,&serverdb);
 
  if(serverdb==NULL) { serverdb = URL; }
  //char* dbname;
  char* serverport=NULL;
  split(serverdb,'/',&serverport,&dbname);

  assert(serverdb!=NULL);
  assert(serverport!=NULL);   
  char* server=NULL;
  char* port=NULL;


  split(serverport,':',&server,&port);

  assert(serverport!=NULL);
  assert(server!=NULL);

  int  iport;
  sscanf(port,"%d",&iport);

  if (libinited == 1)
    {
      //printf("init client stubs\n");
      clientStubs_init(server,iport);
    }
}

//---------------------------------------------------------------------------
//  Exported   methods
//---------------------------------------------------------------------------


void sqlite3_free(void *p)
{
   sqliteFree(p);
}



int sqlite3_open(const char *zFilename, sqlite3 **db)
{ char URL[1024];
  char *dbname;
  libinited++;
  strncpy(URL,zFilename,sizeof(URL));
  parseDatabaseURL(URL,dbname);		// pass a copy, preserve zFilename as const

  sqlite3 *dbx = new sqlite3;
  dbx->flags = 0;		// win32 debug initializes with debug values
  dbx->handle = 0;		// so make sure these have good values
  dbx->errmsg[0]=(char)0;
  *db = dbx;			// sqlite3 always returns
  int errcode;
  int res = svc_sqlite_open((char*)dbname, &errcode, (char **)&dbx->errmsg[0],&dbx->handle);
  if(res==STACK_OK)
  {
	return(errcode);
  }
  else
  {
   return(CLIENT_ERROR_BASE+res);
  }
}

int sqlite3_close(sqlite3 *db)
{  STACK_Int errorcode=0;
   int res = svc_sqlite_close(db->handle,&errorcode);
   delete db;
   libinited--;
   if (libinited == 0)
   {
    clientStubs_deinit();
   }
   if(res==STACK_OK)
   {
	return(errorcode);
   }
   else
   {
   return(CLIENT_ERROR_BASE+res);
   }
}


/*
** Compile a single statement of SQL into a virtual machine.  Return one
** of the SQLITE_ success/failure codes.  Also write an error message into
** memory obtained from malloc() and make *pzErrMsg point to that message.
*/
int sqlite3_prepare(
  sqlite3 *db,                 /* The database on which the SQL executes */
  const char *zSql,           /* The SQL to be executed */
  const char **pzTail,        /* OUT: Next statement after the first */
  sqlite3_stmt **ppVm,           /* OUT: The virtual machine */
  char **pzErrMsg             /* OUT: Write error messages here */
)
{
  int hvm=0;
  int errcode=0;
  unsigned int tailIndex=0;
  int res = svc_sqlite_compile(db->handle,(char*)zSql,(int*)&tailIndex,&hvm,&errcode,pzErrMsg);
  if ((res == STACK_OK))
  {
    if (tailIndex)
      {
	(*pzTail) = (char*)((unsigned int)zSql + tailIndex - 1);
      }
    else
      {
	(*pzTail) = 0;
      }

    if (errcode != SQLITE_OK)
     {
      *ppVm = 0;
     }
    else
    {
      sqlite3_stmt *vm = new sqlite3_stmt;
      vm->handle = hvm;
      vm->colValues.items = 0;
      vm->colNames.items = 0;
	*ppVm = vm;
    }
    return res;
  }
  else
  {
    *ppVm = 0;
    return CLIENT_ERROR_BASE+res;
  }
}



int sqlite3_step(
  sqlite3_stmt *vm,              /* The virtual machine to execute */
  int *pN,                     /* OUT: Number of columns in result */
  const char ***pazValue,      /* OUT: Column data */
  const char ***pazColName     /* OUT: Column names and datatypes */
)
{ int errcode;
  vm->clear();
  int res = svc_sqlite_step(vm->handle,&errcode,&(vm->colValues),&(vm->colNames));
  if ((res == STACK_OK))
  {
    *pN = vm->colValues.len;
    *pazValue = (const char**)vm->colValues.items;
    *pazColName = (const char**)vm->colNames.items;
    return errcode;
  }
  else
  {
    return CLIENT_ERROR_BASE+res;
  }
}

int sqlite3_finalize(sqlite3_stmt* vm, char **pzErrMsg)
{
  if (vm == 0) return SQLITE_OK;
  int errcode;
  int res = svc_sqlite_finalize(vm->handle,&errcode,pzErrMsg);
  if ((res == STACK_OK))
  {
	vm->clear();
    delete vm;
    return errcode;
  }
  else
  {
    return CLIENT_ERROR_BASE+res;
  }
}

/*
** This routine deletes the virtual machine, writes any error message to
** *pzErrMsg and returns an SQLite return code in the same way as the
** sqlite_finalize() function.
**
** Additionally, if ppVm is not NULL, *ppVm is left pointing to a new virtual
** machine loaded with the compiled version of the original query ready for
** execution.
**
** If sqlite_reset() returns SQLITE_SCHEMA, then *ppVm is set to NULL.
**
******* THIS IS AN EXPERIMENTAL API AND IS SUBJECT TO CHANGE ******
*/
int sqlite3_reset(sqlite3_stmt* vm, char **pzErrMsg)
{
  if (vm == 0) return SQLITE_OK;
  int errcode;
  int res = svc_sqlite_reset(vm->handle,&errcode,pzErrMsg);
  if ((res == STACK_OK))
  {	vm->clear();
    delete vm;
    return errcode;
  }
  else
  {
    return CLIENT_ERROR_BASE+res;
  }
}

int sqlite3_changes(sqlite3* db)
{
  int changes;
  int res = svc_sqlite_changes(db->handle,&changes);
  if (res == STACK_OK)
   return changes;
  else
   return -1;
}

sqlite_int64 sqlite3_last_insert_rowid(sqlite3* db)
{
  int rowid;
  int res = svc_sqlite_last_insert_rowid(db->handle,&rowid);
  if (res == STACK_OK)
   return rowid;
  else
   return -1;
}


/* This function causes any pending database operation to abort and
** return at its earliest opportunity.  This routine is typically
** called in response to a user action such as pressing "Cancel"
** or Ctrl-C where the user wants a long query operation to halt
** immediately.
*/
void sqlite3_interrupt(sqlite3* db)
{
   svc_sqlite_interrupt(db->handle);
}


const char *sqlite3_libversion(void)
{
  char* version;
  int res = svc_sqlite_libversion(&version);
  if (res == STACK_OK)
   return version;
  else
   return 0;
}

#if 0
const char *sqlite_libencoding(void)
{
  char* encoding;
  int res = svc_sqlite_libencoding(&encoding);
  if (res == STACK_OK)
   return encoding;
  else
   return 0;
}
#endif

int sqlite3_complete(const char *sql)
{
   //currently no right implementation
   return 1;
}

/*
** Register a function that is called at every invocation of sqlite_exec()
** or sqlite_compile().  This function can be used (for example) to generate
** a log file of all SQL executed against a database.
*/
void *sqlite3_trace(sqlite3*, void(*xTrace)(void*,const char*), void*)
{
   printf("sqlite_trace is not supported in client\n");
   return 0;
}


int sqlite3_set_authorizer(
  sqlite3*,
  int (*xAuth)(void*,int,const char*,const char*,const char*,const char*),
  void *pUserData
)
{
  printf("sqlite_set_authorizer is not supported in client\n");
  return 0;
}



/*
** Use the following routines to create new user-defined functions.  See
** the documentation for details.
*/
int sqlite3_create_function(
  sqlite3*,                  /* Database where the new function is registered */
  const char *zName,        /* Name of the new function */
  int nArg,                 /* Number of arguments.  -1 means any number */
  void (*xFunc)(sqlite3_context*,int,const char**),  /* C code to implement */
  void *pUserData           /* Available via the sqlite_user_data() call */
)
{
  return 0;
}

int sqlite3_create_aggregate(
  sqlite3*,                  /* Database where the new function is registered */
  const char *zName,        /* Name of the function */
  int nArg,                 /* Number of arguments */
  void (*xStep)(sqlite3_context*,int,const char**), /* Called for each row */
  void (*xFinalize)(sqlite3_context*),       /* Called once to get final result */
  void *pUserData           /* Available via the sqlite_user_data() call */
)
{
   return 0;
}

/*
** Use the following routine to define the datatype returned by a
** user-defined function.  The second argument can be one of the
** constants SQLITE_NUMERIC, SQLITE_TEXT, or SQLITE_ARGS or it
** can be an integer greater than or equal to zero.  The datatype
** will be numeric or text (the only two types supported) if the
** argument is SQLITE_NUMERIC or SQLITE_TEXT.  If the argument is
** SQLITE_ARGS, then the datatype is numeric if any argument to the
** function is numeric and is text otherwise.  If the second argument
** is an integer, then the datatype of the result is the same as the
** parameter to the function that corresponds to that integer.
*/
int sqlite3_function_type(
  sqlite3 *db,               /* The database there the function is registered */
  const char *zName,        /* Name of the function */
  int datatype              /* The datatype for this function */
)
{
   return 0;
}
//#define SQLITE_NUMERIC     (-1)
//#define SQLITE_TEXT        (-2)
//#define SQLITE_ARGS        (-3)

/*
** The user function implementations call one of the following four routines
** in order to return their results.  The first parameter to each of these
** routines is a copy of the first argument to xFunc() or xFinialize().
** The second parameter to these routines is the result to be returned.
** A NULL can be passed as the second parameter to sqlite_set_result_string()
** in order to return a NULL result.
**
** The 3rd argument to _string and _error is the number of characters to
** take from the string.  If this argument is negative, then all characters
** up to and including the first '\000' are used.
**
** The sqlite_set_result_string() function allocates a buffer to hold the
** result and returns a pointer to this buffer.  The calling routine
** (that is, the implmentation of a user function) can alter the content
** of this buffer if desired.
*/
char *sqlite3_set_result_string(sqlite3_context*,const char*,int)
{
   return 0;
}
void sqlite3_set_result_int(sqlite3_context*,int)
{

}
void sqlite3_set_result_double(sqlite3_context*,double)
{

}
void sqlite3_set_result_error(sqlite3_context*,const char*,int)
{

}

/*
** The pUserData parameter to the sqlite_create_function() and
** sqlite_create_aggregate() routines used to register user functions
** is available to the implementation of the function using this
** call.
*/
void *sqlite3_user_data(sqlite3_context*)
{
  return 0;
}

/*
** Aggregate functions use the following routine to allocate
** a structure for storing their state.  The first time this routine
** is called for a particular aggregate, a new structure of size nBytes
** is allocated, zeroed, and returned.  On subsequent calls (for the
** same aggregate instance) the same buffer is returned.  The implementation
** of the aggregate can use the returned buffer to accumulate data.
**
** The buffer allocated is freed automatically be SQLite.
*/
void *sqlite3_aggregate_context(sqlite3_context*, int nBytes)
{
  return 0;
}

/*
** The next routine returns the number of calls to xStep for a particular
** aggregate function instance.  The current call to xStep counts so this
** routine always returns at least 1.
*/
int sqlite3_aggregate_count(sqlite3_context*)
{
   return 0;
}


/*
** This routine registers a callback with the SQLite library.  The
** callback is invoked for every attempt to access a column of a table
** in the database.  The callback returns SQLITE_OK if access is allowed,
** SQLITE_DENY if the entire SQL statement should be aborted with an error
** and SQLITE_IGNORE if the column should be treated as a NULL value.
*/
int sqlite3_set_authorizer(
  sqlite3*,
  int (*xAuth)(void*,int,const char*,const char*),
  void *pUserData
)
{
   return 0;
}


/*
** This routine identifies a callback function that is invoked
** whenever an attempt is made to open a database table that is
** currently locked by another process or thread.  If the busy callback
** is NULL, then sqlite_exec() returns SQLITE_BUSY immediately if
** it finds a locked table.  If the busy callback is not NULL, then
** sqlite_exec() invokes the callback with three arguments.  The
** second argument is the name of the locked table and the third
** argument is the number of times the table has been busy.  If the
** busy callback returns 0, then sqlite_exec() immediately returns
** SQLITE_BUSY.  If the callback returns non-zero, then sqlite_exec()
** tries to open the table again and the cycle repeats.
**
** The default busy callback is NULL.
**
** Sqlite is re-entrant, so the busy handler may start a new query. 
** (It is not clear why anyone would every want to do this, but it
** is allowed, in theory.)  But the busy handler may not close the
** database.  Closing the database from a busy handler will delete 
** data structures out from under the executing query and will 
** probably result in a coredump.
*/
void sqlite3_busy_handler(sqlite3*, int(*)(void*,const char*,int), void*)
{

}

/*
** This routine sets a busy handler that sleeps for a while when a
** table is locked.  The handler will sleep multiple times until 
** at least "ms" milleseconds of sleeping have been done.  After
** "ms" milleseconds of sleeping, the handler returns 0 which
** causes sqlite_exec() to return SQLITE_BUSY.
**
** Calling this routine with an argument less than or equal to zero
** turns off all busy handlers.
*/
int sqlite3_busy_timeout(sqlite3*, int ms)
{
	return(0);
}

/*
** Return a static string that describes the kind of error specified in the
** argument.
*/
const char *sqlite3_error_string(int rc){
  const char *z=NULL;
  switch( rc ){
    case SQLITE_OK:         z = "not an error";                          break;
    case SQLITE_ERROR:      z = "SQL logic error or missing database";   break;
    case SQLITE_INTERNAL:   z = "internal SQLite implementation flaw";   break;
    case SQLITE_PERM:       z = "access permission denied";              break;
    case SQLITE_ABORT:      z = "callback requested query abort";        break;
    case SQLITE_BUSY:       z = "database is locked";                    break;
    case SQLITE_LOCKED:     z = "database table is locked";              break;
    case SQLITE_NOMEM:      z = "out of memory";                         break;
    case SQLITE_READONLY:   z = "attempt to write a readonly database";  break;
    case SQLITE_INTERRUPT:  z = "interrupted";                           break;
    case SQLITE_IOERR:      z = "disk I/O error";                        break;
    case SQLITE_CORRUPT:    z = "database disk image is malformed";      break;
    case SQLITE_NOTFOUND:   z = "table or record not found";             break;
    case SQLITE_FULL:       z = "database is full";                      break;
    case SQLITE_CANTOPEN:   z = "unable to open database file";          break;
    case SQLITE_PROTOCOL:   z = "database locking protocol failure";     break;
    case SQLITE_EMPTY:      z = "table contains no data";                break;
    case SQLITE_SCHEMA:     z = "database schema has changed";           break;
    case SQLITE_TOOBIG:     z = "too much data for one table row";       break;
    case SQLITE_CONSTRAINT: z = "constraint failed";                     break;
    case SQLITE_MISMATCH:   z = "datatype mismatch";                     break;
    case SQLITE_MISUSE:     z = "library routine called out of sequence";break;
    case SQLITE_NOLFS:      z = "kernel lacks large file support";       break;
    case SQLITE_AUTH:       z = "authorization denied";                  break;
    case SQLITE_FORMAT:     z = "auxiliary database format error";       break;
    case SQLITE_RANGE:      z = "bind index out of range";               break;
    case SQLITE_NOTADB:     z = "file is encrypted or is not a database";break;
    default:                z = "unknown error";                         break;
  }
  return z;
}


//---------------------------------------------------------------------------
//    The implementation of the methods below is copied from sqlite sources.
//    As long as methods above are implemented correctly, the following
//    methods should also produce correct results.
//---------------------------------------------------------------------------



/*
** Execute SQL code.  Return one of the SQLITE_ success/failure
** codes.  Also write an error message into memory obtained from
** malloc() and make *pzErrMsg point to that message.
**
** If the SQL is a query, then for each row in the query result
** the xCallback() function is called.  pArg becomes the first
** argument to xCallback().  If xCallback=NULL then no callback
** is invoked, even for queries.
*/
int sqlite3_exec(
  sqlite3 *db,                 /* The database on which the SQL executes */
  const char *zSql,           /* The SQL to be executed */
  sqlite3_callback xCallback,  /* Invoke this callback routine */
  void *pArg,                 /* First argument to xCallback() */
  char **pzErrMsg             /* Write error messages here */
)
{
  int rc = SQLITE_OK;
  const char *zLeftover=NULL;
  sqlite3_stmt *pVm=NULL;
  int nRetry = 0;
  int nChange = 0;
  int nCallback;

  while( rc==SQLITE_OK && zSql && zSql[0] )
  {
    pVm = 0;
    rc = sqlite3_prepare(db, zSql, &zLeftover, &pVm, pzErrMsg);
    if( rc!=SQLITE_OK ){
//      assert( pVm==0 || sqlite_malloc_failed );
      return rc;
    }
    if( pVm==0 ){
      /* This happens if the zSql input contained only whitespace */
      break;
    }
//    db->nChange += nChange;
    nCallback = 0;
    while(1){
      int nArg;
      char **azArg, **azCol;
      rc = sqlite3_step(pVm, &nArg, (const char***)&azArg,(const char***)&azCol);
      if( rc==SQLITE_ROW ){
        if( xCallback!=0 && xCallback(pArg, nArg, azArg, azCol) ){
          sqlite3_finalize(pVm, 0);
          return SQLITE_ABORT;
        }
        nCallback++;
      }else{
		  if( (rc==SQLITE_DONE) 
			&& (nCallback==0)
			&& ((db->flags & SQLITE_NullCallback)!=0)
			&& (xCallback!=0) )
		{ //printf("**Null Callback** %x\n",db->flags);
          xCallback(pArg, nArg, azArg, azCol);
        }
        rc = sqlite3_finalize(pVm, pzErrMsg);
        if( rc==SQLITE_SCHEMA && nRetry<2 ){
          nRetry++;
          rc = SQLITE_OK;
          break;
        }
/*        if( db->pVdbe==0 ){
          nChange = db->nChange;
        }
*/        
        nRetry = 0;
		zSql = zLeftover;
        if(zSql)
		{
         while( isspace(zSql[0]) ) zSql++;
		}
        break;
      }
    }
  }
  return rc;
}


/*
** This structure is used to pass data from sqlite_get_table() through
** to the callback function is uses to build the result.
*/
typedef struct TabResult {
  char **azResult;
  char *zErrMsg;
  int nResult;
  int nAlloc;
  int nRow;
  int nColumn;
  int nData;
  int rc;
} TabResult;

/*
** This routine is called once for each row in the result table.  Its job
** is to fill in the TabResult structure appropriately, allocating new
** memory as necessary.
*/
static int sqlite3_get_table_cb(void *pArg, int nCol, char **argv, char **colv){
  TabResult *p = (TabResult*)pArg;
  int need;
  int i;
  char *z;

  //printf("callback row=%d\n",p->nRow);
  /* Make sure there is enough space in p->azResult to hold everything
  ** we need to remember from this invocation of the callback.
  */
  if( p->nRow==0 && argv!=0 ){
    need = nCol*2;
  }else{
    need = nCol;
  }
  if( p->nData + need >= p->nAlloc ){
    char **azNew;
    p->nAlloc = p->nAlloc*2 + need + 1;
   // debug("try realloc\n");
    azNew = (char**) realloc( p->azResult, sizeof(char*)*p->nAlloc );
    if( azNew==0 ){
      p->rc = SQLITE_NOMEM;
      return 1;
    }
    p->azResult = azNew;
  }

  /* If this is the first row, then generate an extra row containing
  ** the names of all columns.
  */
  if( p->nRow==0 ){
    p->nColumn = nCol;
    for(i=0; i<nCol; i++){
      if( colv[i]==0 ){
        z = 0;
      }else{
//       debug("try malloc\n");
        z = (char*)malloc( strlen(colv[i])+1 );
        if( z==0 ){
          p->rc = SQLITE_NOMEM;
          return 1;
        }
        strcpy(z, colv[i]);
      }
      p->azResult[p->nData++] = z;
    }
  }else if( p->nColumn!=nCol ){
    /*
    sqliteSetString(&p->zErrMsg,
       "sqlite_get_table() called with two or more incompatible queries",
       (char*)0);
    */
    p->rc = SQLITE_ERROR;
    return 1;
  }

  /* Copy over the row data
  */
  if( argv!=0 ){
    for(i=0; i<nCol; i++){
      if( argv[i]==0 ){
        z = 0;
      }else{
        int slen=strlen(argv[i])+1;
      //  printf("slen = %d\n",slen);
      //  debug("try malloc 2\n");
        z = (char*)malloc(slen);
      //  debug("done malloc 2\n");
        if( z==0 ){
          p->rc = SQLITE_NOMEM;
          return 1;
        }
        strcpy(z, argv[i]);
      }
      p->azResult[p->nData++] = z;
    }
    p->nRow++;
  }
  return 0;
}

/*
** Query the database.  But instead of invoking a callback for each row,
** malloc() for space to hold the result and return the entire results
** at the conclusion of the call.
**
** The result that is written to ***pazResult is held in memory obtained
** from malloc().  But the caller cannot free this memory directly.  
** Instead, the entire table should be passed to sqlite_free_table() when
** the calling procedure is finished using it.
*/
int sqlite3_get_table(
  sqlite3 *db,                 /* The database on which the SQL executes */
  const char *zSql,           /* The SQL to be executed */
  char ***pazResult,          /* Write the result table here */
  int *pnRow,                 /* Write the number of rows in the result here */
  int *pnColumn,              /* Write the number of columns of result here */
  char **pzErrMsg             /* Write error messages here */
){
  int rc;
  TabResult res;

  if( pazResult==0 ){ return SQLITE_ERROR; }
  *pazResult = 0;
  if( pnColumn ) *pnColumn = 0;
  if( pnRow ) *pnRow = 0;
  res.zErrMsg = 0;
  res.nResult = 0;
  res.nRow = 0;
  res.nColumn = 0;
  res.nData = 1;
  res.nAlloc = 20;
  res.rc = SQLITE_OK;
  res.azResult = (char**)malloc( sizeof(char*)*res.nAlloc );
  if( res.azResult==0 ){
    return SQLITE_NOMEM;
  }
  res.azResult[0] = 0;
  //debug("about to exec \n");
  rc = sqlite3_exec(db, zSql, sqlite3_get_table_cb, &res, pzErrMsg);
  if( res.azResult ){
    res.azResult[0] = (char*)res.nData;
  }
  if( rc==SQLITE_ABORT ){
    //debug("aborting\n");
    sqlite3_free_table(&res.azResult[1]);
    if( res.zErrMsg ){
      if( pzErrMsg ){
        free(*pzErrMsg);
        *pzErrMsg = res.zErrMsg;
        sqliteStrRealloc(pzErrMsg);
      }else{
        sqliteFree(res.zErrMsg);
      }
    }
    return res.rc;
  }
   sqliteFree(res.zErrMsg);
  if( rc!=SQLITE_OK ){
    //debug("freeing table\n");

    sqlite3_free_table(&res.azResult[1]);
    return rc;
  }
  if( res.nAlloc>res.nData ){
    char **azNew;
    azNew = (char**)realloc( res.azResult, sizeof(char*)*(res.nData+1) );
    if( azNew==0 ){
     // debug("freeing table 2\n");
      sqlite3_free_table(&res.azResult[1]);
      return SQLITE_NOMEM;
    }
    res.nAlloc = res.nData+1;
    res.azResult = azNew;
  }
  *pazResult = &res.azResult[1];
  if( pnColumn ) *pnColumn = res.nColumn;
  if( pnRow ) *pnRow = res.nRow;
  return rc;
}

/*
** This routine frees the space the sqlite_get_table() malloced.
*/
void sqlite3_free_table(
  char **azResult             /* Result returned from from sqlite_get_table() */
){
  if( azResult ){
    int i, n;
    azResult--;
    if( azResult==0 ) return;
    n = (int)azResult[0];
    for(i=1; i<n; i++){ if( azResult[i] ) free(azResult[i]); }
    free(azResult);
  }
}

// extensions
const char *sqlite3_errmsg(sqlite3 *db)
{	static STACK_Str msg;
	int errcode = svc_sqlite_errmsg(db->handle,&msg);
	if(errcode==STACK_OK)
	{	
	return(msg);	
	}
	return(NULL);
}

#ifdef ANDROMEDA

int sqlite3_DB_Exists(const char *zFilename)
{ char URL[1024];
  char *dbname;
  libinited++;
  strncpy(URL,zFilename,sizeof(URL));

  parseDatabaseURL(URL,dbname);	// pass a copy, preserve zFilename as const

 
  int errcode=0;
  // res is the internal error code
  // errocde is the real return value
  int res = svc_sqlite_db_exists((char*)dbname, &errcode);

  libinited--;
  if (libinited == 0)
   {
    clientStubs_deinit();
   }

  return(errcode);
}
#endif

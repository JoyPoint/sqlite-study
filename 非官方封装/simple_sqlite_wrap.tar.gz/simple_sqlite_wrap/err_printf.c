/***************************************************************************
 *            err_printf.c
 *
 *  Tue Jun 20 16:10:26 2006
 *  Copyright  2006 
 *  Email: jwamicha@yahoo.co.uk
 *  
 *  Comments:
 *  1. Only prints message if DEBUG is on (ie DEBUG = 1)
 ****************************************************************************/
#include <stdarg.h>
#include <stdio.h>

#define DEBUG 1

int err_printf(const char *fmt, ...);

//if DEBUG is on then print message to stderr using fprintf function
int err_printf(const char *fmt, ...)
{	
	int i;
	
	if(DEBUG == 1)
	{
		va_list ap;	
		va_start(ap, fmt);
		i = vfprintf(stderr, fmt, ap);
		va_end(ap);		
	}
	
	return i;
}
